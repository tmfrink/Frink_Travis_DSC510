print('Hello World! I am Amro')
